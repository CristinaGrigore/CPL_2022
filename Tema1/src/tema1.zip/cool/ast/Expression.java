package cool.ast;

public abstract class Expression extends Instruction {
    Expression(String name) {
        super(name);
    }
}
